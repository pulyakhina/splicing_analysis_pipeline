#!/usr/bin/perl

use warnings;
use strict;

if (@ARGV < 3)
{
    print "USAGE: $0 <input wiggle file> <average coverage of the gold standard sample> <desirable area under the curve under normalization>\n";
    exit;
}

#my %exon_positions = ();
my $coef = $ARGV[1];
my $area = $ARGV[2];

open (WIG, $ARGV[0]);
while (<WIG>)
{
    chomp;
    if ($_ =~ /(^\d+)\D(\d+)/)
    {
	my $new_cov = ($2 / $coef) * $area;
	print "$1\t$new_cov\n";
    }
    else
    {
	print "$_\n";
    }
}
close (WIG);
