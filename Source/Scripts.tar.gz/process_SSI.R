# ==========================================================================================================
#
#      Usage: Rscript ./process_SSI.R output_folder ssi_output.txt rna.wig annotation.txt output_header
#
# ==========================================================================================================

# Reading input files

args<-commandArgs(TRUE)
dir <- args[1] # directory for output plots amd files
input_ssi <- args[2] # SSI text file
input_wig <- args[3] # input wiggle file, please remove the first two lines
input_annotation <- args[4] # annotation
input_header <- args[5]

rna <- read.table(input_wig, sep="\t", skip=2)
colnames(rna) <- c("pos", "cov")

annotation <- read.table(input_annotation, sep="\t")
colnames(annotation) <- c("region", "number", "start", "end")

ssi <- read.table(input_ssi, sep='\t', header=F)
ssi_proper <- data.frame(ssi$V2, ssi$V4, ssi$V6, ssi$V8, ssi$V10)
# ssi_all contains e/(e+i) value for 5' and 3' :
ssi_all <- data.frame(ssi_proper[1], ssi_proper[2], ssi_proper[3], ssi_proper[2]/(ssi_proper[2]+ssi_proper[3]), ssi_proper[4], ssi_proper[5], ssi_proper[4]/(ssi_proper[4]+ssi_proper[5]))
colnames (ssi_all) <- c("intron_num", "ex_ex_5", "ex_int_5", "ssi_5", "ex_ex_3", "ex_int_3", "ssi_3")



# Defining functions

funcCalcMed <- function (x, ann)
{
# Function to calculate median of regions from annotation
# ann is annotation file. Format:
#  region number     start       end 
# 1   exon      1 180630234 180630524 
# 2 intron      1 180630525 180632439 
# 3   exon      2 180632440 180632783 
# 4 intron      2 180632784 180651121 
# 5   exon      3 180651122 180651174 
#
# x is RNA coverage, wiggle file. Format:
#         pos cov 
# 1 180630234   0 
# 2 180630235   0 
	median_region <- c() # initializing file with medians of regions
	for (j in 1:nrow(ann))
	{
		median_region[j] <- median(x[x$pos %in% c(ann[j,3]:ann[j,4]),2])
	}
	median_region
}

funcCalcMean <- function (x, ann)
{
        mean_region <- c()
        for (j in 1:nrow(ann))
        {
                mean_region[j] <- mean(x[x$pos %in% c(ann[j,3]:ann[j,4]),2])
        }
        mean_region
}


funcOddValues <- function (vect)
{
# OddValues will print only odd values from an input vector VECT
	row <- seq(1, length(vect), 2)
	temp <- vect[row]
	temp
}

funcEvenValues <- function (vect)
{
# EvenValues will print only even values from an input vector VECT
	row <- seq(2, length(vect), 2)
	temp <- vect[row]
	temp
}

# Manipulations with splice site index

# ssis is a vector containing 1_5', 1_3', 2_5', 2_3', etc
ssis <- c()
for (i in 1:length(ssi_all[,1]))
{
	ssis <- c(ssis, ssi_all[i,4])
	ssis <- c(ssis, ssi_all[i,7])
}

# names is a vector containing 17_5', 17_3', 16_5', 16_3', etc
names <- c()
for (i in ssi_all[,1])
{
	x = c(i, "_5'")
	name1 <- paste(x, collapse="")
	y = c(" ")
	name2 <- paste(y, collapse="")
	names <- c(names, name1, name2)
}


# Manipulations with medians

rna_med <- funcCalcMed(rna, annotation)
rna_med_ex <- funcOddValues(rna_med)
rna_med_int <- funcEvenValues(rna_med)

med_ex <- data.frame(rna_med_ex)
med_int <- data.frame(rna_med_int)

# Manipulations with means

rna_mean <- funcCalcMean(rna, annotation)
rna_mean_ex <- funcOddValues(rna_mean)
rna_mean_int <- funcEvenValues(rna_mean)

mean_ex <- data.frame(rna_mean_ex)
mean_int <- data.frame(rna_mean_int)

# Creating filenames for output

filename_ssi_pdf <- paste(dir, "/", input_header, "_SSI.pdf", sep="")
filename_ssi_txt <- paste(dir, "/", input_header, "_SSI.txt", sep="")
filename_ex_pdf <- paste(dir, "/", input_header, "_exon_medians.pdf", sep="")
filename_int_pdf <- paste(dir, "/", input_header, "_intron_medians.pdf", sep="")
filename_ex_mean_pdf <- paste(dir, "/", input_header, "_exon_means.pdf", sep="")
filename_int_mean_pdf <- paste(dir, "/", input_header, "_intron_means.pdf", sep="")
filename_all_pics <- paste(dir, "/", input_header, "_med_SSI.pdf", sep="")
filename_ex_med_txt <- paste(dir, "/", input_header, "_med_ex.txt", sep="")
filename_int_med_txt <- paste(dir, "/", input_header, "_med_int.txt", sep="")
filename_ex_mean_txt <- paste(dir, "/", input_header, "_mean_ex.txt", sep="")
filename_int_mean_txt <- paste(dir, "/", input_header, "_mean_int.txt", sep="")


# Creating plots


pdf(filename_ssi_pdf)
barplot(rev(ssis), horiz=TRUE, main="Splice Site Index", names.arg=rev(names), cex.names=0.4, col = c("grey", "black"), xlim=c(0, 1), las=1, cex.axis=0.5, cex.lab=0.5)
dev.off()

write.table(ssi_all, file=filename_ssi_txt, sep="\t", quote=FALSE, row.names=F)
write.table(med_ex, file=filename_ex_med_txt, sep="\t", quote=FALSE, row.names=T)
write.table(med_int, file=filename_int_med_txt, sep="\t", quote=FALSE, row.names=T)
write.table(mean_ex, file=filename_ex_mean_txt, sep="\t", quote=FALSE, row.names=T)
write.table(mean_int, file=filename_int_mean_txt, sep="\t", quote=FALSE, row.names=T)


pdf(filename_ex_mean_pdf)
barplot(rna_mean_ex, horiz=TRUE, main="Means of exonic coverage", names.arg=1:length(rna_mean_ex), cex.names=0.4, col = "grey", las=1, xlab="Mean of coverage", ylab="Exon number")
dev.off()

pdf(filename_int_mean_pdf)
barplot(rna_mean_int, horiz=TRUE, main="Means of intronic coverage", names.arg=1:length(rna_mean_int), cex.names=0.4, col = "black", las=1, xlab="Mean of coverage", ylab="Intron number")
dev.off()

pdf(filename_ex_pdf)
barplot(rna_med_ex, horiz=TRUE, main="Medians of exonic coverage", names.arg=1:length(rna_med_ex), cex.names=0.4, col = "grey", las=1, xlab="Median of coverage", ylab="Exon number")
dev.off()

pdf(filename_int_pdf)
barplot(rna_med_int, horiz=TRUE, main="Medians of intronic coverage", names.arg=1:length(rna_med_int), cex.names=0.4, col = "black", las=1, xlab="Median of coverage", ylab="Intron number")
dev.off()

pdf(filename_all_pics)
par(mfrow=c(1,3))
barplot(rev(rna_med_ex), horiz=TRUE, main="Medians of exonic coverage", names.arg=rev(1:length(rna_med_ex)), cex.names=0.6, col = "grey", las=1, xlab="Median of coverage", ylab="Exon number")
barplot(rev(ssis), horiz=TRUE, main="Splice Site Index", names.arg=rev(names), cex.names=0.5, col = c("grey", "black"), xlim=c(0, 1), las=1)
barplot(rev(rna_med_int), horiz=TRUE, main="Medians of intronic coverage", names.arg=rev(1:length(rna_med_int)), cex.names=0.6, col = "black", las=1, xlab="Median of coverage", ylab="Intron number")
dev.off()

