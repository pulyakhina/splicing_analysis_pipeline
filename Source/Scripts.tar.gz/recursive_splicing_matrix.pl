#!/usr/bin/perl

#use warnings;
use strict;

my %annotation = ();

if (@ARGV < 3)
{
    print "USAGE: $0 annotation_tex_file peaks.wig split_reads.sam

annotation_tex_file format:
exon	1	180630474	180630524
intron	1	180630525	180632439
exon	2	180632440	180632783
intron	2	180632784	180633463
exon	2a	180633464	180633484
intron	2a	180633485	180651121

peaks.wig should contain positions that were called as peaks or drops (the
output of the ''wiggelen derivative'' command.

Format:
180630374 479
180630524 218
180632537 -22
180649270 -75
180651121 -200

split_reads.sam should contain split reads that were split at positions present
in peaks.wig (otherwise you will have reads splitting canonical exon-exon
junctions in your output). Such split_all.sam file can be generated as follows:

get_split_reads_for_wigg.pl split_reads.noExEx.sam peaks.wig > split_all.sam

File ''split_reads.noExEx.sam'' should contain split reads, but not reads
spanning exon-exon junctions, it can be created by the following procedure:

-1- cat input.sam | awk '\$6 ~ /N/ { print \$0 }' > split_all.sam
-2- exclude_exex_reads.pl annotation_tex_file input.sam > split_reads.noExEx.sam

";
    exit;
}

open (ANN, $ARGV[0]);
while (<ANN>)
{
    chomp;
    if ($_ =~ /exon/)
    {
	my @temp_arr = split '\t', $_;
	$annotation{$temp_arr[2]-1} = "int".($temp_arr[1]-1)."-"."ex$temp_arr[1]";
	$annotation{$temp_arr[3]+1} =  "ex$temp_arr[1]"."-"."int$temp_arr[1]";
	$annotation{$temp_arr[2]} = "int".($temp_arr[1]-1)."-"."ex$temp_arr[1]";
	$annotation{$temp_arr[3]} = "ex$temp_arr[1]"."-"."int$temp_arr[1]";
	foreach my $i (sort(($temp_arr[2]+1)..($temp_arr[3]-1)))
	{
	    $annotation{$i} = "exon".$temp_arr[1];
	}
    }
    elsif ($_ =~ /intron/)
    {
	my @temp_arr = split '\t', $_;
	foreach my $i (sort(($temp_arr[2]+1)..($temp_arr[3]-1)))
	{
	    $annotation{$i} = "int".$temp_arr[1];
	}
    }
}
close (ANN);

my %wig_donors = ();
my %wig_acceptors = ();

open (WIG, $ARGV[1]);
while (<WIG>)
{
    chomp;
    if ($_ =~ /\d+.*\d$/)
    {
	my @temp = split '\s', $_;
	my $pos = $temp[0];
	my $cov = $temp[1];
	if ($annotation{$pos})
	{
	    if ($_ =~ /\-/)
	    {
		$wig_acceptors{$pos} = $annotation{$pos};
	    }
	    else
	    {
		$wig_donors{$pos} = $annotation{$pos};
	    }
	}
    }
}
close (WIG);

my %reads_peaks = ();
my %matrix = ();
my %matrix_acc = ();
my %matrix_don = ();

open (SAM, $ARGV[2]);
while (<SAM>)
{
    chomp;
    if ($_ =~ /^[A-Za-z]/)
    {
	my @temp_arr = split '\t', $_;
	my @cigar = split /([A-Za-z])/, $temp_arr[5];
	my @pre_splits = ();
	foreach my $i (0..$#cigar)
	{
	    if ($i % 2)
	    {
		my $temp_elm = join '', $cigar[$i-1], $cigar[$i];
		push (@pre_splits, $temp_elm);
	    }
	}
	my $counter = $temp_arr[3];
	my $donor = 0;
	my $acceptor = 0;
	foreach my $s (0..$#pre_splits)
	{
	    if ($pre_splits[$s] =~ /(\d+)([A-Z])/)
	    {
		my $num = $1;
		my $let = $2;
		my $local_count = 0;
		if ($let =~ /S/) { next; }
		elsif ($let =~ /I/) { next; }
		elsif ($let =~ /N/)
		{
		    $donor = $counter-1;
		    $counter += $num;
		    $acceptor = $counter-1;
		    if (($wig_donors{$donor} and $wig_acceptors{$acceptor}))
		    {
			my $key = $donor."-".$wig_donors{$donor}."__".$acceptor."-".$wig_acceptors{$acceptor};
			$matrix{$key} += 1;
		    }
		    elsif (($wig_donors{($donor-1)} and $wig_acceptors{($acceptor-1)}))
		    {
			my $key = ($donor-1)."-".$wig_donors{($donor-1)}."__".($acceptor-1)."-".$wig_acceptors{($acceptor-1)};
			$matrix{$key} += 1;
		    }
		    elsif ($wig_donors{$donor} and !$wig_acceptors{$acceptor})
		    {
			my $key = $donor."-".$wig_donors{$donor};
			$matrix_don{$key} += 1;
		    }
		    elsif (!$wig_donors{$donor} and $wig_acceptors{$acceptor})
		    {
			my $key = $acceptor."-".$wig_acceptors{$acceptor};
			$matrix_acc{$key} += 1;
		    }
		}
		else
		{
		    $counter += $num;
		}
	    }
	}
    }
}
close (SAM);

open (OUT_COUNTS, ">$ARGV[2].recursive_counts.txt");

foreach my $i (sort keys %matrix_acc)
{
    if ($i !~ /exon/)
    {
	print OUT_COUNTS "No_acceptor__$i\t$matrix_acc{$i}\n";
    }
}

foreach my $i (sort keys %matrix_don)
{
    if ($i !~ /exon/)
    {
	print OUT_COUNTS "No_donor__$i\t$matrix_don{$i}\n";
    }
}

my %matrix_output = ();
my @donors = ();
my @acceptors = ();
my %donor_order = ();
my %acceptor_order = ();
my $count_d = 1;
my $count_a = 1;
my %matrix_data = ();

foreach my $i (sort keys %matrix)
{
    $i =~ /(\d+\-\w.*)\_\_(\d+\-\w.*)/;
    my $donor = $1;
    my $acceptor = $2;
    if (($donor !~ /exon/) and ($acceptor !~ /exon/))
    {
	print OUT_COUNTS "$i\t$matrix{$i}\n";
	if (!$donor_order{$donor})
	{
	    $donor_order{$donor} = $count_d;
	    $count_d += 1;
	}
	if (!$acceptor_order{$acceptor})
	{
	    $acceptor_order{$acceptor} = $count_a;
	    $count_a += 1;
	}
    }
}
close (OUT_COUNTS);

open (OUT_MATR, ">$ARGV[2].recursive_matrix.txt");
foreach my $i (sort keys %matrix)
{
    $i =~ /(\d+\-\w.*)\_\_(\d+\-\w.*)/;
    my $donor = $1;
    my $acceptor = $2;
    if (($donor !~ /exon/) and ($acceptor !~ /exon/))
    {
	my $key = $donor."_".$acceptor;
	$matrix_data{$key} = $matrix{$i};
    }
}

print OUT_MATR "d\\a\t";
foreach my $i (sort {$acceptor_order{$a} <=> $acceptor_order{$b}} keys %acceptor_order)
{
    print OUT_MATR "$i\t";
}
print OUT_MATR "\n";

foreach my $i (sort {$donor_order{$a} <=> $donor_order{$b}} keys %donor_order)
{
    print OUT_MATR "$i\t";
    foreach my $j (sort {$acceptor_order{$a} <=> $acceptor_order{$b}} keys %acceptor_order)
    {
	my $temp_key = $i."_".$j;
	if ($matrix_data{$temp_key})
	{ print OUT_MATR $matrix_data{$temp_key}."\t"; }
	else { print OUT_MATR "0\t"; }
    }
    print OUT_MATR "\n";
}
close (OUT_MATR);
