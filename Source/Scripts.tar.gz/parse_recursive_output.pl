#!/usr/bin/perl

use warnings;
use strict;

if (@ARGV < 3)
{
    print "USAGE: $0 <list> <matrix> <number_of_exons>
where <list> is the output of the \"recursive_matrix.pl\" script and
<number_of_exons> is the number of exons in the analyzed gene.
";
    exit;
}

my $exon_count = $ARGV[2];
my $intron_count = $exon_count-1;

my $output_counts = "$ARGV[0].strand";
my $output_matrix = "$ARGV[1].strand";

open (OUT_C, ">$output_counts");
open (F, $ARGV[0]);
while (<F>)
{
    chomp;
    if ($_ =~ /(.*)\t(.*)/)
    {
	my @string = split '__', $1;
	my $count = $2;
# parsing the left part $string[1]
	if ($string[1] =~ /^(\d+)\-int(\d+)$/)
	{
	    print OUT_C "$1-int", $intron_count-$2+1, "__";
	}
	if ($string[1] =~ /^(\d+)\-int(\d+)\-ex(\d+)$/)
	{
	    print OUT_C "$1-ex", $exon_count-$3+1, "-int", $intron_count-$2+1, "__";
	}
	if ($string[1] =~ /^(\d+)\-ex(\d+)\-int(\d+)$/)
	{
	    print OUT_C "$1-int", $intron_count-$3+1, "-ex", $exon_count-$2+1, "__";
	}

# parsing the left part $string[0]
	if ($string[0] =~ /^(\d+)\-int(\d+)$/)
	{
	    print OUT_C "$1-int", $intron_count-$2+1, "\t$count\n";
	}
	if ($string[0] =~ /^(\d+)\-int(\d+)\-ex(\d+)$/)
	{
	    print OUT_C "$1-ex", $exon_count-$3+1, "-int", $intron_count-$2+1, "\t$count\n";
	}
	if ($string[0] =~ /^(\d+)\-ex(\d+)\-int(\d+)$/)
	{
	    print OUT_C "$1-int", $intron_count-$3+1, "-ex", $exon_count-$2+1, "\t$count\n";
	}
	if ($string[0] =~ /donor/)
	{
	    print OUT_C "No_acceptor\t$count\n";
	}
	if ($string[0] =~ /acceptor/)
	{
	    print OUT_C "No_donor\t$count\n";
	}
    }
}
close (F);
close (OUT_C);

open (OUT_M, ">$output_matrix");
open (F2, $ARGV[1]);
while (<F2>)
{
    chomp;
    if ($_ =~ /^d\\a/)
    {
	print OUT_M "a\\d\t";
	my @temp_site = split '\t', $_;
	foreach my $i (0..$#temp_site)
	{
	    if ($temp_site[$i] =~ /^(\d+)\-int(\d+)$/)
	    {
		print OUT_M "$1-int", $intron_count-$2+1, "\t";
	    }
	    if ($temp_site[$i] =~ /^(\d+)\-int(\d+)\-ex(\d+)$/)
	    {
		print OUT_M "$1-ex", $exon_count-$3+1, "-int", $intron_count-$2+1, "\t";
	    }
	    if ($temp_site[$i] =~ /^(\d+)\-ex(\d+)\-int(\d+)$/)
	    {
		print OUT_M "$1-int", $intron_count-$3+1, "-ex", $exon_count-$2+1, "\t";
	    }
	}
	print OUT_M "\n";
    }
    else
    {
	my @temp_site = split '\t', $_;
	if ($temp_site[0] =~ /^(\d+)\-int(\d+)$/)
	{
	    print OUT_M "$1-int", $intron_count-$2+1, "\t", join ("\t", @temp_site[1 .. $#temp_site]), "\n";
	}
	if ($temp_site[0] =~ /^(\d+)\-int(\d+)\-ex(\d+)$/)
	{
	    print OUT_M "$1-ex", $exon_count-$3+1, "-int", $intron_count-$2+1, "\t", join ("\t", @temp_site[1 .. $#temp_site]), "\n";
	}
	if ($temp_site[0] =~ /^(\d+)\-ex(\d+)\-int(\d+)$/)
	{
	    print OUT_M "$1-int", $intron_count-$3+1, "-ex", $exon_count-$2+1, "\t", join ("\t", @temp_site[1 .. $#temp_site]), "\n";
	}
    }
}
close (F2);
close (OUT_M);

