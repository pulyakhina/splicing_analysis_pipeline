#!/usr/bin/perl

use warnings;
use strict;

if (@ARGV < 2) { print "USAGE: $0  <annotation file>  <SAM file>  <cutoff (optional, default=500)>\n\n"; exit; }
my $cutoff = 500;
if ($ARGV[2]) { $cutoff = $ARGV[2]; }
my %exons = ();
my %introns = ();

open (ANN, $ARGV[0]);
while (<ANN>)
{
    chomp;
    if ($_ =~ /exon/)
    {
	my @temp = split '\t', $_;
	if ($temp[2] < $temp[3]) { $exons{$temp[2]} = $temp[3]; }
	else { $exons{$temp[3]} = $temp[2]; }
    }
    elsif ($_ =~ /intron/)
    {
	my @temp = split '\t', $_;
	if ($temp[2] < $temp[3]) { $introns{$temp[2]} = $temp[3]; }
	else { $introns{$temp[3]} = $temp[3]; }
    }
}
close (ANN);

my %pair1 = ();
my %pair2 = ();
my %data = ();


open (SAM, $ARGV[1]);
while (<SAM>)
{
    chomp;
    if ($_ =~ /^@/) { next; }
    else
    {
        my @temp = split '\t', $_;
        my $coord1 = $temp[3]; # start
	$temp[5] =~ s/\d+S//;
	$temp[5] =~ s/\d+H//;
	my @temp_ar1 = $temp[5] =~ /(\d+)/g;
	my $score = 0;
	foreach my $i (0..$#temp_ar1)
	{
	    $score += $temp_ar1[$i];
	}
	my $coord2 = $coord1+$score;
	if (($temp[1] & 0x0040) > 0) # the read is the first read in a pair
        {
            $pair1{$temp[0]} = "$temp[3]"."__"."$coord2";
            push (@ { $data{$temp[0]} }, $_);
        }
        else # the read is the second read in a pair
        {
            $pair2{$temp[0]} = "$temp[3]"."__"."$coord2";
            push (@ { $data{$temp[0]} }, $_);
        }
    }
}
close (SAM);

open (small_overhang, ">$ARGV[1].small_overhang.$cutoff");
open (norm_pre, ">$ARGV[1].norm_pre.$cutoff");
open (norm_int, ">$ARGV[1].norm_int.$cutoff");
open (norm_post, ">$ARGV[1].norm_post.$cutoff");
open (large_int, ">$ARGV[1].large_int.$cutoff");
open (large_post, ">$ARGV[1].large_post.$cutoff");
open (large_same_exon, ">$ARGV[1].large_same_exon.$cutoff");
open (un_known, ">$ARGV[1].unknown.$cutoff");
open (un_classified, ">$ARGV[1].unclassified.$cutoff");

my $total_reads = 0;

foreach my $p (keys %pair1)
{
    if ($pair2{$p})
    {
	$pair1{$p} =~ /(\d+)\_\_(\d+)/;
	my $read1_start = $1;
        my $read1_end = $2;
        my $s1_tag = "no";
        my $s1_index = "no";
        my $e1_tag = "no";
        my $e1_index = "no";
        
        $pair2{$p} =~ /(\d+)\_\_(\d+)/;
        my $read2_start = $1;
        my $read2_end = $2;
        my $s2_tag = "no";
        my $s2_index = "no";
        my $e2_tag = "no";
        my $e2_index = "no";
	
	foreach my $i (sort {$a <=> $b} keys %introns)
	{
	    if (($read1_start >= $i) and ($read1_start < $introns{$i}))
	    {
		$s1_tag = "intron";
		$s1_index = $i;
	    }
	    if (($read1_end >= $i) and ($read1_end < $introns{$i}))
	    {
		$e1_tag = "intron";
		$e1_index = $i;
	    }
	    if (($read2_start >= $i) and ($read2_start < $introns{$i}))
	    {
		$s2_tag = "intron";
		$s2_index = $i;
	    }
	    if (($read2_end >= $i) and ($read2_end < $introns{$i}))
	    {
		$e2_tag = "intron";
		$e2_index = $i;
	    }
	}
	
	foreach my $e (sort {$a <=> $b} keys %exons)
	{
	    if (($read1_start >= $e) and ($read1_start < $exons{$e}))
	    {
		$s1_tag = "exon";
		$s1_index = $e;
	    }
	    if (($read1_end >= $e) and ($read1_end < $exons{$e}))
	    {
		$e1_tag = "exon";
		$e1_index = $e;
	    }
	    if (($read2_start >= $e) and ($read2_start < $exons{$e}))
	    {
		$s2_tag = "exon";
		$s2_index = $e;
	    }
	    if (($read2_end >= $e) and ($read2_end < $exons{$e}))
	    {
		$e2_tag = "exon";
		$e2_index = $e;
	    }
	}
	
	#print "$s1_tag\t$s1_index\n$e1_tag\t$e1_index\n$s2_tag\t$s2_index\n$e2_tag\t$e2_index\n";
	
	my @sorted_temp_ar = sort ($read1_start, $read1_end, $read2_start, $read2_end);
        my $dist = abs($sorted_temp_ar[2] - $sorted_temp_ar[1]);
	
	my $read1 = read_class($s1_tag, $e1_tag, $s1_index, $e1_index);
	#print "$read1\t($s1_tag, $e1_tag, $s1_index, $e1_index)\n";
        my $read2 = read_class($s2_tag, $e2_tag, $s2_index, $e2_index);
	#print "$read2\t($s2_tag, $e2_tag, $s2_index, $e2_index)\n";
	
	if ((($read1 eq "intron") and ($read2 eq "intron")) or (($read1 eq "intron") and ($read2 eq "exon")) or (($read2 eq "intron") and ($read1 eq "exon")) or (($read1 eq "intron") and ($read2 eq "int-ex")) or (($read2 eq "intron") and ($read1 eq "int-ex")))
        {
            if (($dist) < $cutoff) { print norm_pre "$data{$p}[0]\n$data{$p}[1]\n"; $total_reads += 1; }
            else { print large_int "$data{$p}[0]\n$data{$p}[1]\n"; $total_reads += 1; }
        }
	elsif ((($read1 eq "intron") and ($read2 eq "ex-ex")) or (($read2 eq "intron") and ($read1 eq "ex-ex")) or (($read1 eq "ex-ex") and ($read2 eq "int-ex")) or (($read2 eq "ex-ex") and ($read1 eq "int-ex")))
        {
            if (($dist) < $cutoff) { print norm_int "$data{$p}[0]\n$data{$p}[1]\n"; $total_reads += 1; }
            else { print large_int "$data{$p}[0]\n$data{$p}[1]\n"; $total_reads += 1; }
        }
        elsif ((($read1 eq "exon") and ($read2 eq "ex-ex")) or (($read2 eq "exon") and ($read1 eq "ex-ex")) or (($read1 eq "ex-ex") and ($read2 eq "ex-ex")))
        {
            if (($dist) < $cutoff) { print norm_post "$data{$p}[0]\n$data{$p}[1]\n"; $total_reads += 1; }
            else { print large_post "$data{$p}[0]\n$data{$p}[1]\n"; $total_reads += 1; }
        }
        elsif (($read1 eq "exon") and ($read2 eq "exon"))
        {
	    if (($dist) < $cutoff) { print un_known "$data{$p}[0]\n$data{$p}[1]\n"; $total_reads += 1; }
	    else
	    {
		if ($s1_index == $s2_index) { print large_same_exon "$data{$p}[0]\n$data{$p}[1]\n"; $total_reads += 1; }
		else { print large_post "$data{$p}[0]\n$data{$p}[1]\n"; $total_reads += 1; }
	    }
        }
        else { print un_classified "$data{$p}[0]\n$data{$p}[1]\n"; $total_reads += 1; }
    }
}

close (small_overhang);
close (norm_pre);
close (norm_int);
close (norm_post);
close (large_int);
close (large_post);
close (un_known);
close (large_same_exon);
close (un_classified);


sub read_class
{
    my $start_tag = shift;
    my $end_tag = shift;
    my $start_index = shift;
    my $end_index = shift;
    
    if (($start_tag eq "intron") & ($end_tag eq "intron")) { return "intron"; }
    elsif ((($start_tag eq "intron") & ($end_tag eq "exon")) or (($start_tag eq "exon") & ($end_tag eq "intron"))) { return "int-ex"; }
    elsif (($start_tag eq "exon") & ($end_tag eq "exon"))
    {
	if ($start_index == $end_index) {return "exon"; }
	elsif ($start_index != $end_index) { return "ex-ex"; }
    }
}
