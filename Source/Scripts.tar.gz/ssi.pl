#!/usr/bin/perl

use warnings;
use strict;

if (@ARGV < 2) { print "USAGE: $0  <annotation file>  <SAM file>\n\n"; exit; }
my $cutoff = 500;
if ($ARGV[2]) { $cutoff = $ARGV[2]; }
my %exons = ();
my %introns = ();
my $intron_count = 0;

open (ANN, $ARGV[0]);
while (<ANN>)
{
    chomp;
    if ($_ =~ /exon/)
    {
	my @temp = split '\t', $_;
	$exons{$temp[2]} = $temp[3];
    }
    elsif ($_ =~ /intron/)
    {
	my @temp = split '\t', $_;
	$introns{$temp[2]} = $temp[3];
	$intron_count += 1;
    }
}
close (ANN);

my %intron_labels = ();
my $l = 1;
foreach my $i (sort {$a <=> $b} keys %introns)
{
	if ($i < $introns{$i})
	{
		$intron_labels{$l}{$i} = $introns{$i};
	}
	else
	{
		$intron_labels{$l}{$introns{$i}} = $i;
	}
	$l += 1;
}

my %exon_labels = ();
my $l2 = 1;
foreach my $i (sort {$a <=> $b} keys %exons)
{
        if ($i < $exons{$i})
        {
                $exon_labels{$l2}{$i} = $exons{$i};
        }
        else
        {
                $exon_labels{$l2}{$exons{$i}} = $i;
        }
        $l2 += 1;
}

#foreach my $i (sort {$a <=> $b} keys %intron_labels)
#{
#	print "$i\t";
#	foreach my $j (keys %{ $intron_labels{$i} })
#	{
#		print "$j..$intron_labels{$i}{$j}\n";
#	}
#}

my %pair1 = ();
my %pair2 = ();
my %data = ();

print "Number of introns is $intron_count\n";

open (SAM, $ARGV[1]);
while (<SAM>)
{
    chomp;
    if ($_ =~ /^@/) { next; }
    else
    {
        my @temp = split '\t', $_;
        my $coord1 = $temp[3]; # start
	$temp[5] =~ s/\d+S//;
	$temp[5] =~ s/\d+H//;
	my @temp_ar1 = $temp[5] =~ /(\d+)/g;
	my $score = 0;
	foreach my $i (0..$#temp_ar1)
	{
	    $score += $temp_ar1[$i];
	}
	my $coord2 = $coord1+$score;
	if (($temp[1] & 0x0040) > 0) # the read is the first read in a pair
        {
            $pair1{$temp[0]} = "$temp[3]"."__"."$coord2";
            push (@ { $data{$temp[0]} }, $_);
        }
        else # the read is the second read in a pair
        {
            $pair2{$temp[0]} = "$temp[3]"."__"."$coord2";
            push (@ { $data{$temp[0]} }, $_);
        }
    }
}
close (SAM);
my $exons = $intron_count+1;
my %ex_ex_5 = ();
my %ex_ex_3 = ();
my %ex_int_5 = ();
my %ex_int_3 = ();


my $total_reads = 0;

foreach my $p (keys %pair1)
{
    if ($pair2{$p})
    {
	$pair1{$p} =~ /(\d+)\_\_(\d+)/;
	my $read1_start = $1;
        my $read1_end = $2;
        my $s1_tag = "no";
        my $s1_index = "no";
        my $e1_tag = "no";
        my $e1_index = "no";
        
        $pair2{$p} =~ /(\d+)\_\_(\d+)/;
        my $read2_start = $1;
        my $read2_end = $2;
        my $s2_tag = "no";
        my $s2_index = "no";
        my $e2_tag = "no";
        my $e2_index = "no";
	
	foreach my $i (sort {$a <=> $b} keys %intron_labels)
	{
	    foreach my $j (keys %{ $intron_labels{$i} })
	    {
		if (($read1_start > $j) and ($read1_start <= $intron_labels{$i}{$j}))
		{
		    $s1_tag = "intron";
		    $s1_index = $i;
		}
		if (($read1_end > $j) and ($read1_end <= $intron_labels{$i}{$j}))
                {   
                    $e1_tag = "intron"; 
                    $e1_index = $i;
                }
		if (($read2_start > $j) and ($read2_start <= $intron_labels{$i}{$j}))
                {   
                    $s2_tag = "intron"; 
                    $s2_index = $i;
                }
		if (($read2_end > $j) and ($read2_end <= $intron_labels{$i}{$j}))
                {   
                    $e2_tag = "intron"; 
                    $e2_index = $i;
                }
	    }
	}
	foreach my $e (sort {$a <=> $b} keys %exon_labels)
	{
	    foreach my $b (keys %{ $exon_labels {$e} })
	    {
		if (($read1_start > $b) and ($read1_start <= $exon_labels{$e}{$b}))
		{
		    $s1_tag = "exon";
		    $s1_index = $e;
		}
                if (($read1_end > $b) and ($read1_end <= $exon_labels{$e}{$b}))
                {
                    $e1_tag = "exon";
                    $e1_index = $e;
                }
                if (($read2_start > $b) and ($read2_start <= $exon_labels{$e}{$b}))
                {
                    $s2_tag = "exon";
                    $s2_index = $e;
                }
                if (($read2_end > $b) and ($read2_end <= $exon_labels{$e}{$b}))
                {
                    $e2_tag = "exon";
                    $e2_index = $e;
                }

	    }
	}
	#print "$s1_tag-$s1_index\t$e1_tag-$e1_index\t$s2_tag-$s2_index\t$e2_tag-$e2_index\n";
	# splicing index
	if (($s1_tag eq "exon") and ($e1_tag eq "exon") and ($s1_index != $e1_index))
        {
            if ($read1_start < $read1_end)
            {
                $ex_ex_3{$s1_index} += 1;
                $ex_ex_5{$e1_index} += 1;
            }
            else
            {
                $ex_ex_5{$s1_index} += 1;
                $ex_ex_3{$e1_index} += 1;
            }
        }
        elsif (($s1_tag eq "exon") and ($e1_tag eq "intron"))
        {
            if ($read1_start < $read1_end) { $ex_int_5{$e1_index} += 1; }
            else { $ex_int_3{$e1_index} += 1; }
        }
        elsif (($s1_tag eq "intron") and ($e1_tag eq "exon"))
        {
            if ($read1_start < $read1_end) { $ex_int_3{$s1_index} += 1; }
            else { $ex_int_5{$s1_index} += 1; }
        }
        if (($s1_tag eq "intron") and ($e1_tag eq "intron") and ($s1_index =! $e1_index))
        {
            $ex_int_3{$s1_index} += 1;
            $ex_int_3{$e1_index} += 1;
            $ex_int_5{$s1_index} += 1;
            $ex_int_5{$e1_index} += 1;
        }
        if (($s2_tag eq "exon") and ($e2_tag eq "exon") and ($s2_index != $e2_index))
        {
            if ($read2_start < $read2_end)
            {
                $ex_ex_3{$s2_index} += 1;
                $ex_ex_5{$e2_index} += 1;
            }
            else
            {
                $ex_ex_5{$s2_index} += 1;
                $ex_ex_3{$e2_index} += 1;
            }
        }
        elsif (($s2_tag eq "exon") and ($e2_tag eq "intron"))
        {
            if ($read2_start < $read2_end) { $ex_int_5{$e2_index} += 1; }
            else { $ex_int_3{$e2_index} += 1; }
        }
        elsif (($s2_tag eq "intron") and ($e2_tag eq "exon"))
        {
            if ($read2_start < $read2_end) { $ex_int_3{$s2_index} += 1; }
            else { $ex_int_5{$s2_index} += 1; }
        }
        if (($s2_tag eq "intron") and ($e2_tag eq "intron") and ($s2_index =! $e2_index))
        {
            $ex_int_3{$s2_index} += 1;
            $ex_int_3{$e2_index} += 1;
            $ex_int_5{$s2_index} += 1;
            $ex_int_5{$e2_index} += 1;
        }
    }
}

foreach my $i (1..$intron_count)
{
    print "INTRON\t$i\t";
    print "EX-EX_5\t";
    if ($ex_ex_3{$i}) { print "$ex_ex_3{$i}\t"; }
    else { print "0\t"; }
    print "EX-INT_5\t";
    if ($ex_int_5{$i}) { print "$ex_int_5{$i}\t"; }
    else { print "0\t"; }

    print "EX-EX_3\t";
    if ($ex_ex_5{$i+1}) { print "$ex_ex_5{$i+1}\t"; }
    else { print "0\t"; }
    print "EX-INT_3\t";
    if ($ex_int_3{$i}) { print "$ex_int_3{$i}\t"; }
    else { print "0\t"; }

    print "\n";
}


