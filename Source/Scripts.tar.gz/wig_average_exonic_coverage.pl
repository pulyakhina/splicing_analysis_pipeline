#!/usr/bin/perl

use warnings;
use strict;

if (@ARGV < 2)
{
    print "USAGE: $0 <annotation> <input wiggle file>

The script will calculate the average coverage of the exons (specified in the
annotation).

";
    exit;
}




my %exon_positions = ();

open (F, $ARGV[0]);
while (<F>)
{
    chomp;
    if ($_ =~ /exon/)
    {
	my @temp_arr = split '\t', $_;
	if ($temp_arr[2] < $temp_arr[3])
	{
	    foreach my $i ($temp_arr[2]..$temp_arr[3])
	    {
                $exon_positions{$i} = 1;
            }
	}
	if ($temp_arr[2] > $temp_arr[3])
        {
            foreach my $i ($temp_arr[3]..$temp_arr[2])
            {
                $exon_positions{$i} = 1;
            }
        }
    }
}
close (F);

my $coverage = 0;

open (WIG, $ARGV[1]);
while (<WIG>)
{
    chomp;
    if ($_ =~ /(^\d+)\D(\d+)/)
    {
	if ($exon_positions{$1})
	{
	    $coverage += $2;
	}
    }

}
close (WIG);

my $length = keys %exon_positions;
my $average_coverage = $coverage/$length;
print "$ARGV[1]\t$average_coverage\n";

