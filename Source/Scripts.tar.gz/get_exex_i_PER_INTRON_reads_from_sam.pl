#!/usr/bin/perl

use warnings;
use strict;

if (@ARGV < 2) { print "USAGE: $0  <annotation file>  <SAM file> <cutoff (optional, default=500)>\n\n"; exit; }
my $cutoff = 500;
if ($ARGV[3]) { $cutoff = $ARGV[3]; }

my %exons = ();
my %introns = ();
my %exon_index = ();
my %intron_index = ();
my $gene_end = 0;

my %reads_per_intron_before = ();
my %reads_per_intron_after = ();

open (ANN, $ARGV[0]);
while (<ANN>)
{
    chomp;
    if ($_ =~ /exon/)
    {
	my @temp = split '\t', $_;
	if ($temp[2] < $temp[3])
	{
	    $exons{$temp[2]} = $temp[3];
	    $exon_index{$temp[2]} = $temp[1];
	}
	else
	{
	    $exons{$temp[3]} = $temp[2];
	    $exon_index{$temp[3]} = $temp[1];
	}
    }
    elsif ($_ =~ /intron/)
    {
	$gene_end += 1;
	my @temp = split '\t', $_;
	if ($temp[2] < $temp[3])
	{
	    $introns{$temp[2]} = $temp[3];
	    $intron_index{$temp[2]} = $temp[1];
	}
	else
	{
	    $introns{$temp[3]} = $temp[2];
	    $intron_index{$temp[3]} = $temp[1];
	}
    }
}
close (ANN);

my %pair1 = ();
my %pair2 = ();
my %data = ();

open (SAM, $ARGV[1]);
while (<SAM>)
{
    chomp;
    if ($_ =~ /^@/) { next; }
    else
    {
        my @temp = split '\t', $_;
        my $coord1 = $temp[3]; # start
	$temp[5] =~ s/\d+S//g;
	$temp[5] =~ s/\d+H//g;
	my @temp_ar1 = $temp[5] =~ /(\d+)/g;
	my $score = 0;
	foreach my $i (0..$#temp_ar1)
	{
	    $score += $temp_ar1[$i];
	}
	my $coord2 = $coord1+$score;
	if (($temp[1] & 0x0040) > 0) # the read is the first read in a pair
        {
            $pair1{$temp[0]} = "$temp[3]"."__"."$coord2";
            push (@ { $data{$temp[0]} }, $_);
        }
        else # the read is the second read in a pair
        {
            $pair2{$temp[0]} = "$temp[3]"."__"."$coord2";
            push (@ { $data{$temp[0]} }, $_);
        }
    }
}
close (SAM);

open (AFTER_A, ">$ARGV[1].ee_after_i.sam");
open (BEFORE_A, ">$ARGV[1].ee_before_i.sam");

foreach my $p (keys %pair1)
{
    if ($pair2{$p})
    {
	$pair1{$p} =~ /(\d+)\_\_(\d+)/;
	my $read1_start = $1;
        my $read1_end = $2;
        my $s1_tag = "no";
        my $s1_index = "no";
        my $e1_tag = "no";
        my $e1_index = "no";
        
        $pair2{$p} =~ /(\d+)\_\_(\d+)/;
        my $read2_start = $1;
        my $read2_end = $2;
        my $s2_tag = "no";
        my $s2_index = "no";
        my $e2_tag = "no";
        my $e2_index = "no";

	foreach my $i (sort {$a <=> $b} keys %introns)
	{
	    if (($read1_start > ($i+4)) and ($read1_start < ($introns{$i}-4)))
	    {
		$s1_tag = "intron";
		$s1_index = $i;
	    }
	    if (($read1_end > ($i+4)) and ($read1_end < ($introns{$i}-4)))
	    {
		$e1_tag = "intron";
		$e1_index = $i;
	    }
	    if (($read2_start > ($i+4)) and ($read2_start < ($introns{$i}-4)))
	    {
		$s2_tag = "intron";
		$s2_index = $i;
	    }
	    if (($read2_end > ($i+4)) and ($read2_end < ($introns{$i}-4)))
	    {
		$e2_tag = "intron";
		$e2_index = $i;
	    }
	}
	
	foreach my $e (sort {$a <=> $b} keys %exons)
	{
	    if (($read1_start >= $e) and ($read1_start < $exons{$e}))
	    {
		$s1_tag = "exon";
		$s1_index = $e;
	    }
	    if (($read1_end >= $e) and ($read1_end < $exons{$e}))
	    {
		$e1_tag = "exon";
		$e1_index = $e;
	    }
	    if (($read2_start >= $e) and ($read2_start < $exons{$e}))
	    {
		$s2_tag = "exon";
		$s2_index = $e;
	    }
	    if (($read2_end >= $e) and ($read2_end < $exons{$e}))
	    {
		$e2_tag = "exon";
		$e2_index = $e;
	    }
	}
	
	my $read1 = read_class($s1_tag, $e1_tag, $s1_index, $e1_index);
        my $read2 = read_class($s2_tag, $e2_tag, $s2_index, $e2_index);
	
	if (($read1 eq "intron") and ($read2 eq "ex-ex") and (abs($read1_start-$read1_end) < 110))
	{
	    if ($intron_index{$s1_index} < min($exon_index{$s2_index}, $exon_index{$e2_index}))
	    {
		$reads_per_intron_before{$intron_index{$s1_index}} += 1;
		print BEFORE_A "$data{$p}[0]\n$data{$p}[1]\n";
	    }
	    else
	    {
		$reads_per_intron_after{$intron_index{$s1_index}} += 1;
		print AFTER_A "$data{$p}[0]\n$data{$p}[1]\n";
	    }
	}
	elsif (($read1 eq "int-int") and ($read2 eq "ex-ex") and (abs($read1_start-$read1_end) < 110))
	{
	    if ($intron_index{$s1_index} < min($exon_index{$s2_index}, $exon_index{$e2_index}))
	    {
		$reads_per_intron_before{$intron_index{$s1_index}} += 1;
		print BEFORE_A "$data{$p}[0]\n$data{$p}[1]\n";
	    }
	    else
	    {
		$reads_per_intron_after{$intron_index{$s1_index}} += 1;
		print AFTER_A "$data{$p}[0]\n$data{$p}[1]\n";
	    }
	}
	elsif (($read1 eq "int-ex") and ($read2 eq "ex-ex") and (abs($read1_start-$read1_end) < 110))
	{
	    if ($intron_index{$s1_index} < min($exon_index{$s2_index}, $exon_index{$e2_index}))
	    {
		$reads_per_intron_before{$intron_index{$s1_index}} += 1;
		print BEFORE_A "$data{$p}[0]\n$data{$p}[1]\n";
	    }
	    else
	    {
		$reads_per_intron_after{$intron_index{$s1_index}} += 1;
		print AFTER_A "$data{$p}[0]\n$data{$p}[1]\n";
	    }
	}
	elsif (($read1 eq "ex-int") and ($read2 eq "ex-ex") and (abs($read1_start-$read1_end) < 110))
	{
	    if ($intron_index{$e1_index} < min($exon_index{$s2_index}, $exon_index{$e2_index}))
	    {
		$reads_per_intron_before{$intron_index{$e1_index}} += 1;
		print BEFORE_A "$data{$p}[0]\n$data{$p}[1]\n";
	    }
	    else
	    {
		$reads_per_intron_after{$intron_index{$e1_index}} += 1;
		print AFTER_A "$data{$p}[0]\n$data{$p}[1]\n";
	    }
	}
	elsif (($read2 eq "intron") and ($read1 eq "ex-ex") and (abs($read2_start-$read2_end) < 110))
        {
            if ($intron_index{$s2_index} < min($exon_index{$s1_index}, $exon_index{$e1_index}))
            {
                $reads_per_intron_before{$intron_index{$s2_index}} += 1;
                print BEFORE_A "$data{$p}[0]\n$data{$p}[1]\n";
            }
            else
            {
                $reads_per_intron_after{$intron_index{$s2_index}} += 1;
                print AFTER_A "$data{$p}[0]\n$data{$p}[1]\n";
            }
        }
        elsif (($read2 eq "int-int") and ($read1 eq "ex-ex") and (abs($read2_start-$read2_end) < 110))
        {
            if ($intron_index{$s2_index} < min($exon_index{$s1_index}, $exon_index{$e1_index}))
            {
                $reads_per_intron_before{$intron_index{$s2_index}} += 1;
                print BEFORE_A "$data{$p}[0]\n$data{$p}[1]\n";
            }
            else
            {
                $reads_per_intron_after{$intron_index{$s2_index}} += 1;
                print AFTER_A "$data{$p}[0]\n$data{$p}[1]\n";
            }
        }
        elsif (($read2 eq "int-ex") and ($read1 eq "ex-ex") and (abs($read2_start-$read2_end) < 110))
        {
            if ($intron_index{$s2_index} < min($exon_index{$s1_index}, $exon_index{$e1_index}))
            {
                $reads_per_intron_before{$intron_index{$s2_index}} += 1;
                print BEFORE_A "$data{$p}[0]\n$data{$p}[1]\n";
            }
            else
            {
                $reads_per_intron_after{$intron_index{$s2_index}} += 1;
                print AFTER_A "$data{$p}[0]\n$data{$p}[1]\n";
            }
	}
        elsif (($read2 eq "ex-int") and ($read1 eq "ex-ex") and (abs($read2_start-$read2_end) < 110))
        {
            if ($intron_index{$e2_index} < min($exon_index{$s1_index}, $exon_index{$e1_index}))
            {
                $reads_per_intron_before{$intron_index{$e2_index}} += 1;
                print BEFORE_A "$data{$p}[0]\n$data{$p}[1]\n";
            }
            else
            {
                $reads_per_intron_after{$intron_index{$e2_index}} += 1;
                print AFTER_A "$data{$p}[0]\n$data{$p}[1]\n";
            }
        }
    }
}
close (AFTER_A);
close (BEFORE_A);

foreach my $i (1..$gene_end)
{
    print "Intron=$i\t";
    if ($reads_per_intron_before{$i}) { print "BEFORE=$reads_per_intron_before{$i}\t"; }
    else { print "BEFORE=0\t"; }
    if ($reads_per_intron_after{$i}) { print "AFTER=$reads_per_intron_after{$i}\t"; }
    else { print "AFTER=0\t"; }
    print "\n";
}

sub read_class
{
    my $start_tag = shift;
    my $end_tag = shift;
    my $start_index = shift;
    my $end_index = shift;
    
#    print "START_TAG=$start_tag\tEND_TAG=$end_tag\tSTART_INDEX=$start_index\tEND_INDEX=$end_index\t";
    
    if (($start_tag eq "intron") and ($end_tag eq "intron"))
    {
	if ($start_index == $end_index) { return "intron"; }
	else { return "int-int"; }
    }
    elsif (($start_tag eq "intron") and ($end_tag eq "exon"))
    {
        return "int-ex";
    }
    elsif (($start_tag eq "exon") and ($end_tag eq "intron"))
    {
        return "ex-int";
    }
    elsif (($start_tag eq "exon") and ($end_tag eq "exon"))
    {
	if ($start_index == $end_index) { return "exon"; }
        else { return "ex-ex"; }
    }
    else { return "no"; }
}

sub min
{
    my $first_val = shift;
    my $second_val = shift;
    if ($first_val < $second_val) { return $first_val; }
    elsif ($first_val > $second_val) { return $second_val; }
    else { return $second_val; }
}

sub max
{
    my $first_val = shift;
    my $second_val = shift;
    if ($first_val < $second_val) { return $second_val; }
    elsif ($first_val > $second_val) { return $first_val; }
    else { return $second_val; }
}
