#!/usr/bin/perl

use warnings;
use strict;

if (@ARGV < 1) { print "USAGE: $0 <input sam file>\nThsis script will calculate number of reads in the input sam file\n\n"; exit; }
my %pair1 = ();
my %pair2 = ();
my %all = ();
open (SAM, $ARGV[0]);
while (<SAM>)
{
    chomp;
    if ($_ =~ /^@/) { next; }
    else
    {
        my @temp = split '\t', $_;
	$all{$temp[0]} = 1;
        if (($temp[1] & 0x0040) > 0) # the read is the first read in a pair
        { $pair1{$temp[0]} = 1; }
        else # the read is the second read in a pair
        { $pair2{$temp[0]} = 1; }
    }
}
close (SAM);
my $num = keys %all;
my $num1 = 0;
foreach my $i (keys %pair1)
{
    if ($pair2{$i}) { $num1 += 1; }
}
print "$ARGV[0]\ttotal=$num\tpaired=$num1\n";
