#!/usr/bin/perl

use warnings;
use strict;

if (@ARGV < 2)
{
    print "\nThis script will go through the list of input wiggle files, find positions that have non-zero coverage in multiple input files and report a sum wiggle files containing such positions and the sum of coverage in all files.

USAGE: $0 <number> fileA.wig fileB.wig fileC.wig ...

where \"number\" is a number of file that should contain non-zero coverage at a certain position.\n\n";
    exit;
}
my %data = (); # all wiggle files will be stored in this hash of arrays; key is position, elements of array are coverage values in all wiggle files
my $global_length = $ARGV[0]; # number of wiggle files that a position should be present in
my $chr = "";

foreach my $i (1..$#ARGV)
{
    open (F, $ARGV[$i]);
    while (<F>)
    {
	chomp;
	if ($_ =~ /^variableStep/) # for the header of the output file
	{
	    $chr = $_;
	}
	if (($_ =~ /^(\d+)\s(.*\d.*)/) or ($_ =~ /^(\d+)\t(.*\d.*)/))
	{
	    my $pos = $1;
	    my $cov = $2;
	    if ($cov != 0)
	    {
		push @{ $data{$pos} }, $cov;
	    }
	}
    }
    close (F);
}

print "track type=wiggle_0 name=\"Overlap_of_@ARGV\" description=\"Overlap_of_@ARGV\"\n$chr\n"; #printing the header

foreach my $i1 (sort {$a <=> $b} keys %data)
{
#    print "-> @{$data{$i1}}[0]\n";
    my $local_length = @{$data{$i1}};
    if ($local_length < $global_length) { next; }
    else # if coverage is non-zero in at least $global_length number of the input wiggle files
    {
	my $negative = 0;
	foreach my $sign (@{$data{$i1}})
	{
	    if ($sign =~ /\-/)
	    {
#		print "NEGATIVE $sign\t";
		$negative += 1;
	    }
#	    print "SIGN $sign\t";
	}
#	print "TOTAL MINUSES $negative\n";
	if (($negative == 0) or ($negative >= $global_length))
	{
#	    print "@{$data{$i1}}\t$negative\n";
	    my $sum = eval join '+', @{$data{$i1}}; # sum of all coverage values from all input wiggle files
	    print "$i1 $sum\n";
	}
#	my $sum = eval join '+', @{$data{$i1}}; # sum of all coverage values from all input wiggle files
#	print "$i1 $sum\n";
    }
}
