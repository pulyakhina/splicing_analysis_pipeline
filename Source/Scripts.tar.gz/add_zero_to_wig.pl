#!/usr/bin/perl

use warnings;
use strict;

if (@ARGV < 3)
{
    print "USAGE: $0 <wiggle file> <interval> <output filename>
The script will take the input wiggle file and the input interval on a chromosome.
You MUST have only one chromosome in your input wiggle file!
";
    exit;
}

$ARGV[1] =~ /(\d+)\-(\d+)/;
my $start = 0;
my $end = 0;

if ($1 < $2)
{
    $start = $1;
    $end = $2;
}

if ($1 > $2)
{
    $start = $2;
    $end = $1;
}

if ($1 == $2)
{
    print "$ARGV[1] is not an interval ($1 equals $2). Please put the correct numbers to make an interval.\n";
    exit;
}

my %wiggle = ();

open (OUT, ">$ARGV[2]");
open (F, $ARGV[0]);
while (<F>)
{
    chomp;
    if (($_ =~ /^(\d+)\t(\d+)$/) or ($_ =~ /^(\d+)\s(\d+)$/))
    {
	$wiggle{$1} = $2;
    }
    else
    {
	print OUT "$_\n";
    }
}
close (F);

my $additionals = 0;

foreach my $i ($start..$end)
{
	if ($wiggle{$i}) { print OUT "$i\t$wiggle{$i}\n"; }
#	elsif (!$wiggle{$i}) { print OUT "$i\t0\n"; $additionals += 1;}
	elsif (!$wiggle{$i}) { print OUT "$i\t0\n"; }
}
print "\n";
#foreach my $i ($start..$end)
#{
#    if ($wiggle{$i}) { print OUT "$i\t$wiggle{$i}\n"; }
#    else
#    {
#	print OUT "$i\t0\n";
#	$wiggle{$i} = "0_zero";
#	$additionals += 1;
#    }
#}
close (OUT);
print "$additionals zero-coverage lines was added to $ARGV[0], the new file is $ARGV[2]\n";
