#!/usr/bin/perl

use warnings;
use strict;

if (@ARGV < 2) { print "USAGE: $0  <annotation file>  <SAM file> <cutoff (optional, default=500)>\n\n"; exit; }
my $cutoff = 500;
if ($ARGV[3]) { $cutoff = $ARGV[3]; }

my %exons = ();
my %introns = ();
my %exon_index = ();
my %intron_index = ();
my $gene_end = 0;

my %reads_per_intron_before = ();
my %reads_per_intron_after = ();

open (ANN, $ARGV[0]);
while (<ANN>)
{
    chomp;
    if ($_ =~ /exon/)
    {
	my @temp = split '\t', $_;
	if ($temp[2] < $temp[3])
	{
	    $exons{$temp[2]} = $temp[3];
	    $exon_index{$temp[2]} = $temp[1];
	}
	else
	{
	    $exons{$temp[3]} = $temp[2];
	    $exon_index{$temp[3]} = $temp[1];
	}
    }
    elsif ($_ =~ /intron/)
    {
	$gene_end += 1;
	my @temp = split '\t', $_;
	if ($temp[2] < $temp[3])
	{
	    $introns{$temp[2]} = $temp[3];
	    $intron_index{$temp[2]} = $temp[1];
	}
	else
	{
	    $introns{$temp[3]} = $temp[2];
	    $intron_index{$temp[3]} = $temp[1];
	}
    }
}
close (ANN);

my %pair1 = ();
my %pair2 = ();
my %data1 = ();
my %data2 = ();

open (SAM, $ARGV[1]);
while (<SAM>)
{
    chomp;
    if ($_ =~ /^@/) { next; }
    else
    {
        my @temp = split '\t', $_;
        my $coord1 = $temp[3]; # start
	$temp[5] =~ s/\d+S//g;
	$temp[5] =~ s/\d+H//g;
	my @temp_ar1 = $temp[5] =~ /(\d+)/g;
	my $score = 0;
	foreach my $i (0..$#temp_ar1)
	{
	    $score += $temp_ar1[$i];
	}
	my $coord2 = $coord1+$score;
	if (($temp[1] & 0x0040) > 0) # the read is the first read in a pair
        {
            $pair1{$temp[0]} = "$temp[3]"."__"."$coord2";
            push (@ { $data1{$temp[0]} }, $_);
        }
        else # the read is the second read in a pair
        {
            $pair2{$temp[0]} = "$temp[3]"."__"."$coord2";
            push (@ { $data2{$temp[0]} }, $_);
        }
    }
}
close (SAM);

foreach my $p (keys %pair1)
{
    $pair1{$p} =~ /(\d+)\_\_(\d+)/;
    my $read1_start = $1;
    my $read1_end = $2;
    my $s1_tag = "no";
    my $s1_index = "no";
    my $e1_tag = "no";
    my $e1_index = "no";

    foreach my $e (sort {$a <=> $b} keys %exons)
    {
        if (($read1_start >= $e) and ($read1_start < $exons{$e}))
        {
            $s1_tag = "exon";
            $s1_index = $e;
        }
        if (($read1_end >= $e) and ($read1_end < $exons{$e}))
        {
            $e1_tag = "exon";
            $e1_index = $e;
        }
    }
    foreach my $i (sort {$a <=> $b} keys %introns)
    {
        if (($read1_start > ($i+4)) and ($read1_start < ($introns{$i}-4)))
        {
            $s1_tag = "intron";
            $s1_index = $i;
        }
        if (($read1_end > ($i+4)) and ($read1_end < ($introns{$i}-4)))
        {
            $e1_tag = "intron";
            $e1_index = $i;
        }
    }
    my $read1 = read_class($s1_tag, $e1_tag, $s1_index, $e1_index);
    if (($read1 ne "no") and ($read1 ne "ex-ex"))
    {
	print "$data1{$p}[0]\n";
    }
}

foreach my $p (keys %pair2)
{
    $pair2{$p} =~ /(\d+)\_\_(\d+)/;
    my $read1_start = $1;
    my $read1_end = $2;
    my $s1_tag = "no";
    my $s1_index = "no";
    my $e1_tag = "no";
    my $e1_index = "no";

    foreach my $e (sort {$a <=> $b} keys %exons)
    {
        if (($read1_start >= $e) and ($read1_start < $exons{$e}))
        {
            $s1_tag = "exon";
            $s1_index = $e;
        }
        if (($read1_end >= $e) and ($read1_end < $exons{$e}))
        {
            $e1_tag = "exon";
            $e1_index = $e;
        }
    }
    foreach my $i (sort {$a <=> $b} keys %introns)
    {
        if (($read1_start > ($i+4)) and ($read1_start < ($introns{$i}-4)))
        {
            $s1_tag = "intron";
            $s1_index = $i;
        }
        if (($read1_end > ($i+4)) and ($read1_end < ($introns{$i}-4)))
        {
            $e1_tag = "intron";
            $e1_index = $i;
        }
    }
    my $read1 = read_class($s1_tag, $e1_tag, $s1_index, $e1_index);
    if (($read1 ne "no") and ($read1 ne "ex-ex"))
    {
        print "$data2{$p}[0]\n";
    }
}


sub read_class
{
    my $start_tag = shift;
    my $end_tag = shift;
    my $start_index = shift;
    my $end_index = shift;
    
    if (($start_tag eq "intron") and ($end_tag eq "intron"))
    {
	if ($start_index == $end_index) { return "intron"; }
	else { return "int-int"; }
    }
    elsif (($start_tag eq "intron") and ($end_tag eq "exon"))
    {
        return "int-ex";
    }
    elsif (($start_tag eq "exon") and ($end_tag eq "intron"))
    {
        return "ex-int";
    }
    elsif (($start_tag eq "exon") and ($end_tag eq "exon"))
    {
	if ($start_index == $end_index) { return "exon"; }
        else { return "ex-ex"; }
    }
    else { return "no"; }
}
