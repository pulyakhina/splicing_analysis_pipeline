#!/usr/bin/perl

use warnings;
use strict;

if (@ARGV < 1)
{
    print "USAGE: $0 <gtf annotation> > <txt annotation>

The script converts the gtf annotation in the following format:

exon	1	180630474	180630524
intron	1	180630525	180632439
exon	2	180632440	180632783
intron	2	180632784	180651121
exon	3	180651122	180651174
...

";
    exit;
}

my %coords = ();

open (F, $ARGV[0]);
while (<F>)
{
    chomp;
    if ($_ =~ /^chr/)
    {
	my @temp_str = split '\t', $_;
	$coords{$temp_str[1]} = $temp_str[2];
    }
}
close (F);

my $intron_start = 0;
my $intron_end = 0;

foreach my $i (sort {$a <=> $b} keys %coords)
{
    if (($intron_start == 0) and ($intron_end == 0))
    {
	$intron_start = $coords{$i}+1;
    }
    elsif (($intron_start > 0) and ($intron_end == 0))
    {
	$intron_end = $i-1;
	$coords{$intron_start} = $intron_end;
	$intron_start = $coords{$i}+1;
	$intron_end = 0;
    }
}

my $counter = 0;
my $exon_number = 1;

foreach my $i (sort {$a <=> $b} keys %coords)
{
    $counter += 1;
    if ($counter%2 == 1)
    {
	print "exon\t$exon_number\t$i\t$coords{$i}\n";
    }
    elsif ($counter%2 == 0)
    {
	print "intron\t$exon_number\t$i\t$coords{$i}\n";
	$exon_number += 1;
    }
}
