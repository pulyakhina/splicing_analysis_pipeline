#!/bin/bash 


# PACKAGES
SAMTOOLS=`which samtools`
PILETOOLS=`which piletools`
WIGGELEN=`which wiggelen`
RSCRIPT=`which Rscript`


# SCRIPTS
CLASSIFICATION="PATH_TO_SCRIPTS/class_plus.pl"
MAPPED_READS="PATH_TO_SCRIPTS/mapped_reads_from_sam_file.pl"
SSI_SCRIPT="PATH_TO_SCRIPTS/ssi.pl"
ZERO_TO_WIG="PATH_TO_SCRIPTS/add_zero_to_wig.pl"
AVERAGE_WIG_COV="PATH_TO_SCRIPTS/wig_average_exonic_coverage.pl"
WIG_COV_CHANGE="PATH_TO_SCRIPTS/wig_change_cov.pl"
R_PROCESS="PATH_TO_SCRIPTS/process_SSI.R"
MED_COV_PROBES="PATH_TO_SCRIPTS/med_cov_per_region.pl"
SAM_READS_FROM_REGION="PATH_TO_SCRIPTS/get_sam_reads_within_region.pl"
GET_EXEX_READS_PER_INTRON="PATH_TO_SCRIPTS/get_exex_i_PER_INTRON_reads_from_sam.pl"
GET_EXEX_READS_PER_JUNCTION="PATH_TO_SCRIPTS/get_exex_i_PER_JUNCTION_from_sam.pl"
REMOVE_EX_EX="PATH_TO_SCRIPTS/remove_exex_from_sam.pl"
PARSE_ANN="PATH_TO_SCRIPTS/parse_annotation_gtf2txt.pl"
GET_SPLIT_READ_FOR_WIG="PATH_TO_SCRIPTS/get_split_reads_for_wigg.pl"
RECURS_MATRIX="PATH_TO_SCRIPTS/recursive_splicing_matrix.pl"
PARSE_RECURS_OUTPUT="PATH_TO_SCRIPTS/parse_recursive_output.pl"
WIG_PEAKS="PATH_TO_SCRIPTS/wig_peaks_sign.pl"


# INPUT
INIT_ANNOTATION="PATH_TO_DATA/example_annotation.bed"
CUTOFF_COV="5000"
PROBES_TO_INCLUDE="PATH_TO_DATA/example_region.bed"
REFSEQ="reference.fa"


# Parsing the annotation
ANNOTATION=`echo $INIT_ANNOTATION | sed s/bed/txt/g`
touch $ANNOTATION
$PARSE_ANN $INIT_ANNOTATION > $ANNOTATION


# Getting the region:
chrName=`head -1 $INIT_ANNOTATION | awk '{print $1}'`
position=`cat $ANNOTATION | awk '{print $3 "\t" $4}' | tr "\t" "\n" | awk '{if ($1 > MAX) { MAX = $1 } if (($1 < MIN) || MIN == "") {MIN = $1}} END {print MIN"-"MAX}'`
REGION=`echo $chrName:$position`


# Getting number of exons
EXON_COUNT=`cat $ANNOTATION | grep -c exon`


# Method for nonseq and partially for recursive splicing detection
nonseq() {
INPUT_BAM=$1
OUTPUT_PREFIX=`echo $INPUT_BAM | sed s/bam/results/g`

# Creating sam and wiggle files
$SAMTOOLS view $INPUT_BAM $REGION > $OUTPUT_PREFIX.sam
$SAMTOOLS view -b $INPUT_BAM $REGION > $OUTPUT_PREFIX.ubam
$SAMTOOLS sort $OUTPUT_PREFIX.ubam $OUTPUT_PREFIX
$SAMTOOLS index $OUTPUT_PREFIX.bam
rm $OUTPUT_PREFIX.ubam
$SAMTOOLS mpileup -d 20000 -f $REFSEQ $OUTPUT_PREFIX.bam > $OUTPUT_PREFIX.mpileup
$PILETOOLS mpileup2wig -g $OUTPUT_PREFIX.mpileup $OUTPUT_PREFIX.wig
rm $OUTPUT_PREFIX.mpileup

# Creating files with split reads
cat $OUTPUT_PREFIX.sam | awk '$6 ~ /N/ {print $0}' > $OUTPUT_PREFIX.split.sam
$SAMTOOLS view -bt $REFSEQ.fai $OUTPUT_PREFIX.split.sam > $OUTPUT_PREFIX.split.ubam
$SAMTOOLS sort $OUTPUT_PREFIX.split.ubam $OUTPUT_PREFIX.split
rm $OUTPUT_PREFIX.split.ubam
$SAMTOOLS index $OUTPUT_PREFIX.split.bam

# Classification
$CLASSIFICATION $ANNOTATION $OUTPUT_PREFIX.sam 650
for i in `ls $OUTPUT_PREFIX*sam*650`; do j=`echo $i | sed s/sam\.//g | sed s/650/650.sam/g`; mv $i $j; done
for i in `ls $OUTPUT_PREFIX*norm*650.sam $OUTPUT_PREFIX*large_int*650.sam $OUTPUT_PREFIX*large_post*650.sam`; do $MAPPED_READS $i; done > $OUTPUT_PREFIX.classification.txt

# Calculating Splice Site Index
$SSI_SCRIPT $ANNOTATION $OUTPUT_PREFIX.sam | grep INTRON > $OUTPUT_PREFIX.SSI_temp

# Normalizing the coverage
TEMP_REGION=`echo $REGION | sed s/chr.*\://g`
$ZERO_TO_WIG $OUTPUT_PREFIX.wig $TEMP_REGION $OUTPUT_PREFIX.zero.wig
$AVERAGE_WIG_COV $ANNOTATION $OUTPUT_PREFIX.wig | sed s/.*\\t//g > TEMP_cov
COV=`cat TEMP_cov`
$AVERAGE_WIG_COV $ANNOTATION $OUTPUT_PREFIX.wig
$WIG_COV_CHANGE $OUTPUT_PREFIX.wig $COV $CUTOFF_COV > $OUTPUT_PREFIX.normalized.wig
$WIG_COV_CHANGE $OUTPUT_PREFIX.zero.wig $COV $CUTOFF_COV > $OUTPUT_PREFIX.zero.normalized.wig

$RSCRIPT $R_PROCESS ./ $OUTPUT_PREFIX.SSI_temp $OUTPUT_PREFIX.zero.wig $ANNOTATION $OUTPUT_PREFIX.zero.processed
$RSCRIPT $R_PROCESS ./ $OUTPUT_PREFIX.SSI_temp $OUTPUT_PREFIX.zero.normalized.wig $ANNOTATION $OUTPUT_PREFIX.zero.normalized.processed

# =========================
#  Non-sequential splicing
# =========================
$MED_COV_PROBES $OUTPUT_PREFIX.zero.normalized.wig $ANNOTATION $PROBES_TO_INCLUDE $OUTPUT_PREFIX.probes
$SAM_READS_FROM_REGION $OUTPUT_PREFIX.sam $PROBES_TO_INCLUDE $OUTPUT_PREFIX.junction_focused_reads.sam 0
$GET_EXEX_READS_PER_INTRON $ANNOTATION $OUTPUT_PREFIX.junction_focused_reads.sam >$OUTPUT_PREFIX.intron_focused_counts.txt
$GET_EXEX_READS_PER_JUNCTION $ANNOTATION $OUTPUT_PREFIX.junction_focused_reads.sam

# =========================
#    Recursive splicing
# =========================
$REMOVE_EX_EX $ANNOTATION $OUTPUT_PREFIX.split.sam > $OUTPUT_PREFIX.noExEx.sam

$SAMTOOLS view -bt $REFSEQ.fai $OUTPUT_PREFIX.noExEx.sam > $OUTPUT_PREFIX.noExEx.ubam
$SAMTOOLS sort $OUTPUT_PREFIX.noExEx.ubam $OUTPUT_PREFIX.noExEx
rm $OUTPUT_PREFIX.noExEx.ubam
$SAMTOOLS index $OUTPUT_PREFIX.noExEx.bam
$SAMTOOLS mpileup -d 20000 -f $REFSEQ $OUTPUT_PREFIX.noExEx.bam > $OUTPUT_PREFIX.noExEx.mpileup
$PILETOOLS mpileup2wig -G $OUTPUT_PREFIX.noExEx.mpileup $OUTPUT_PREFIX.noExEx.G.wig
rm $OUTPUT_PREFIX.noExEx.mpileup

echo $REGION | sed 's/\:/\t/g' | sed 's/\-/\t/g' > temp_BED.$OUTPUT_PREFIX

$WIGGELEN fill -g temp_BED.$OUTPUT_PREFIX -o -e $OUTPUT_PREFIX.noExEx.G.wig > $OUTPUT_PREFIX.noExEx.G.filled.wig
rm temp_BED.$OUTPUT_PREFIX
$WIGGELEN derivative -n $OUTPUT_PREFIX.noExEx.G.filled.der.wig -d $OUTPUT_PREFIX.noExEx.G.filled.der.wig $OUTPUT_PREFIX.noExEx.G.filled.wig > $OUTPUT_PREFIX.noExEx.G.filled.der.wig

rm *idx *noExEx.G.filled.wig TEMP_cov
}


# Method for the last step of analyzing recursive splicing -- creating and parsing the matrix
recurs() {
INPUT_SAM=$1
INPUT_PEAKS=$2
REC_PREFIX=`echo $INPUT_SAM | sed s/\.sam//g`

$GET_SPLIT_READ_FOR_WIG $INPUT_SAM $INPUT_PEAKS > $REC_PREFIX.peak.sam
$RECURS_MATRIX $ANNOTATION $INPUT_PEAKS $REC_PREFIX.peak.sam
$PARSE_RECURS_OUTPUT $REC_PREFIX.peak.sam.recursive_counts.txt $REC_PREFIX.peak.sam.recursive_matrix.txt $EXON_COUNT
}

INPUT_FILES=( "$@" )
INPUT_WIGDER_FILES=`echo ${INPUT_FILES[@]} | sed s/bam/results.noExEx.G.filled.der.wig/g`
NUMB_OF_FILES=${#INPUT_FILES[@]}


# Running the analysis of non-sequential and recursive splicing per sample
for FILE1 in "${INPUT_FILES[@]}"
do
    nonseq $FILE1
    echo "Per-sample analysis is done for $FILE1"
done


# Running the recursive splicing analysis on all the input files
$WIG_PEAKS $NUMB_OF_FILES $INPUT_WIGDER_FILES > recurs_splicing_peaks.wig


# Creating and parsing the matrices per sample
for FILE2 in `ls *noExEx.sam`
do
    recurs $FILE2 recurs_splicing_peaks.wig
done

echo DONE
