#!/usr/bin/perl

use warnings;
use strict;

if (@ARGV < 2)
{
    print "USAGE: $0 <input sam file> <list of peaks> > <outpus sam file>

<input sam file>  should be a sam file containing only split reads, excluding
		  reads split over the exon-exon junctions;

<list of peaks>   should be a wiggle file containing coverage of (potential)
		  donor and acceptor splice sites;

<outpus sam file> will be a asm file containing split reads supporting
		  donor-acceptor splice site pairs from the input wiggle file.

";
    exit;
}

my %reads_peaks = ();

open (SAM, $ARGV[0]);
while (<SAM>)
{
    chomp;
    if ($_ =~ /^[A-Za-z]/)
    {
	my @temp_arr = split '\t', $_;
	my @cigar = split /([A-Za-z])/, $temp_arr[5];
	my @pre_splits = ();
	foreach my $i (0..$#cigar)
	{
	    if ($i % 2)
	    {
		my $temp_elm = join '', $cigar[$i-1], $cigar[$i];
		push (@pre_splits, $temp_elm);
#		print "$temp_elm\n";
	    }
	}
#	print "@pre_splits\n\n";
	my $counter = $temp_arr[3];
	foreach my $s (0..$#pre_splits)
	{
	    if ($pre_splits[$s] =~ /(\d+)([A-Z])/)
	    {
		my $num = $1;
		my $let = $2;
		my $local_count = 0;
		if ($let =~ /S/)
		{
		    next;
		}
		elsif ($let =~ /N/)
		{
		    push @{ $reads_peaks{$counter} }, $_;
		    push @{ $reads_peaks{$counter-1} }, $_;
		    $counter += $num;
		    push @{ $reads_peaks{$counter-1} }, $_;
		    push @{ $reads_peaks{$counter} }, $_;
		}
		else
		{
		    $counter += $num;
		}
	    }
	}
    }
}
close (SAM);

my %resulting_reads = ();

open (WIG, $ARGV[1]);
while (<WIG>)
{
    chomp;
    if ($_ =~ /^(\d+)/)
    {
	my $pos = $1;
	if ( $reads_peaks{$pos})
	{
	    foreach my $i (@{$reads_peaks{$pos}})
	    {
		$resulting_reads{$i} = 1;
	    }
	    delete($reads_peaks{$pos});
	}
    }
}
close (WIG);

foreach my $i (keys %resulting_reads)
{
    print "$i\n";
}

#my $k = keys %resulting_reads;
#print "READS $k\n";
