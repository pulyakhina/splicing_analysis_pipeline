#!/usr/bin/perl

use warnings;
use strict;

if (@ARGV < 4)
{
    print "USAGE: $0 <wiggle file> <annotation> <regions.bed> <output prefix>

The script will take the input wiggle file, create a new wiggle file containing only
the positions present in both in the annotation and the regions.bed file. Based on
the annotation it will also calculate median coverage of exons and introns per exon
and per intron.

Tip: you can use regions.bed if you want to exclude some areas when calculating the
median coverage, e.g. pseudogenes or poorly sequenced regions.

";
    exit;
}

my %include = ();
my %intron_coords = ();
my %exon_coords = ();
my %exon_Med = ();
my %intron_Med = ();
my $chr = "";

open (INCLUDE, $ARGV[2]);
while (<INCLUDE>)
{
    chomp;
    if ($_ =~ /chr(.*)\t(\d+)\t(\d+$)/)
    {
	$chr = $1;
	my $start = $2;
	my $end = $3;
	foreach my $i ($start .. $end)
	{
	    $include{$i} = 1;
	}
    }
}
close (INCLUDE);

open (ANNOTATION, $ARGV[1]);
while (<ANNOTATION>)
{
    chomp;
    if ($_ =~ /ntron\t(\d+)\t(\d+)\t(\d+)/)
    {
	my $intron = $1;
	my $start = $2;
	my $end = $3;
	foreach my $j ($start .. $end)
	{
	    if ($include{$j})
	    {
		$intron_coords{$j} = $intron;
	    }
	}
    }
    elsif ($_ =~ /xon\t(\d+)\t(\d+)\t(\d+)/)
    {
	my $exon = $1;
	my $start = $2;
	my $end = $3;
	foreach my $j ($start .. $end)
	{
	    if ($include{$j})
	    {
		$exon_coords{$j} = $exon;
	    }
	}
    }
}
close (ANNOTATION);

open (WIG, $ARGV[0]);
open (WIG_OUT, ">$ARGV[3].wig");
while (<WIG>)
{
    chomp;
    if ($_ =~ /(^\d+)\t([0-9]*.*$)/)
    {
	my $position = $1;
	my $coverage = $2;
	if ($intron_coords{$position})
	{
	    print WIG_OUT "$_\n";
	    my $temp_key = $intron_coords{$position};
	    push @{ $intron_Med{ $temp_key } }, $coverage;
	}
	elsif ($exon_coords{$position})
	{
	    print WIG_OUT "$_\n";
	    my $temp_key = $exon_coords{$position};
	    push @{ $exon_Med{ $temp_key } }, $coverage;
	}
    }
    elsif ($_ =~ /track/)
    {
	print WIG_OUT "track type=wiggle_0 name=\"$ARGV[3]\" description=\"$ARGV[3]\"\n";
    }
    elsif ($_ =~ /variable/)
    {
	print WIG_OUT "variableStep chrom=chr$chr\n";
    }
}
close (WIG);
close (WIG_OUT);

open (EX_OUT, ">$ARGV[3].med_ex.txt");
open (INT_OUT, ">$ARGV[3].med_int.txt");
my %temp_hash = ();
my @temp_arr = ();
foreach my $i (keys %exon_coords)
{
    $temp_hash{$exon_coords{$i}} = 1;
}
foreach my $i (sort {$b <=> $a} keys %temp_hash)
{
    push @temp_arr, $i;
}
my $limit = $temp_arr[0];

foreach my $count (1 .. $limit)
{
    if ($exon_Med{$count})
    {
	my $med = Median( @ { $exon_Med{$count} } );
	print EX_OUT "exon\t", $count,"\t$med\n";
    }
    else
    {
	print EX_OUT "exon\t", $count, "\t0\n";
    }
}

foreach my $count (1 .. $limit-1)
{
    if ($intron_Med{$count})
    {
	my $med = Median( @ { $intron_Med{$count} } );
	print INT_OUT "intron\t", $count,"\t$med\n";
    }
    else
    {
	print INT_OUT "intron\t", $count,"\t0\n";
    }
}
close (EX_OUT);
close (INT_OUT);

sub Median
{
    my @values = @_;
    my @sorted_values = sort {$a <=> $b} @values;
    my $lengthy = @sorted_values;
    if ($lengthy%2 == 0)
    {
	my $index = $lengthy/2;
	my $to_return = ($sorted_values[($index-1)] + $sorted_values[$index]) / 2;
	return $to_return;
    }
    elsif ($lengthy%2 == 1)
    {
	my $index = 0.5 + $lengthy/2;
	return $sorted_values[($index-1)];
    }
}
