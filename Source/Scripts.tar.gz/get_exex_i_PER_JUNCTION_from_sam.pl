#!/usr/bin/perl

use warnings;
use strict;

if (@ARGV < 2) { print "USAGE: $0  <annotation file>  <SAM file> <cutoff (optional, default=500)>\n\n"; exit; }
my $cutoff = 500;
if ($ARGV[3]) { $cutoff = $ARGV[3]; }

my %exons = ();
my %introns = ();
my %exon_index = ();
my %intron_index = ();
my %counts_next = ();
my %counts_last = ();
my %before_a = ();
my %before_d = ();
my %after_a = ();
my %after_d = ();
my $gene_end = 0;

open (ANN, $ARGV[0]);
while (<ANN>)
{
    chomp;
    if ($_ =~ /exon/)
    {
	$gene_end += 1;
	my @temp = split '\t', $_;
	if ($temp[2] < $temp[3])
	{
	    $exons{$temp[2]} = $temp[3];
	    $exon_index{$temp[2]} = $temp[1];
	}
	else
	{
	    $exons{$temp[3]} = $temp[2];
	    $exon_index{$temp[3]} = $temp[1];
	}
    }
    elsif ($_ =~ /intron/)
    {
	my @temp = split '\t', $_;
	if ($temp[2] < $temp[3])
	{
	    $introns{$temp[2]} = $temp[3];
	    $intron_index{$temp[2]} = $temp[1];
	    $counts_last{$temp[1]} = 1;
	    $counts_next{$temp[1]} = 1;
	}
	else
	{
	    $introns{$temp[3]} = $temp[2];
	    $intron_index{$temp[3]} = $temp[1];
	    $counts_next{$temp[1]} = 1;
	    $counts_last{$temp[1]} = 1;
	}
    }
}
close (ANN);

my %pair1 = ();
my %pair2 = ();
my %data = ();

open (SAM, $ARGV[1]);
while (<SAM>)
{
    chomp;
    if ($_ =~ /^@/) { next; }
    else
    {
        my @temp = split '\t', $_;
        my $coord1 = $temp[3]; # start
	$temp[5] =~ s/\d+S//g;
	$temp[5] =~ s/\d+H//g;
	my @temp_ar1 = $temp[5] =~ /(\d+)/g;
	my $score = 0;
	foreach my $i (0..$#temp_ar1)
	{
	    $score += $temp_ar1[$i];
	}
	my $coord2 = $coord1+$score;
	if (($temp[1] & 0x0040) > 0) # the read is the first read in a pair
        {
            $pair1{$temp[0]} = "$temp[3]"."__"."$coord2";
            push (@ { $data{$temp[0]} }, $_);
        }
        else # the read is the second read in a pair
        {
            $pair2{$temp[0]} = "$temp[3]"."__"."$coord2";
            push (@ { $data{$temp[0]} }, $_);
        }
    }
}
close (SAM);

open (AFTER_A, ">$ARGV[1].after_adjacent.sam");
open (AFTER_D, ">$ARGV[1].after_distant.sam");
open (BEFORE_A, ">$ARGV[1].before_adjacent.sam");
open (BEFORE_D, ">$ARGV[1].before_distant.sam");

foreach my $p (keys %pair1)
{
    if ($pair2{$p})
    {
	$pair1{$p} =~ /(\d+)\_\_(\d+)/;
	my $read1_start = $1;
        my $read1_end = $2;
        my $s1_tag = "no";
        my $s1_index = "no";
        my $e1_tag = "no";
        my $e1_index = "no";
        
        $pair2{$p} =~ /(\d+)\_\_(\d+)/;
        my $read2_start = $1;
        my $read2_end = $2;
        my $s2_tag = "no";
        my $s2_index = "no";
        my $e2_tag = "no";
        my $e2_index = "no";

	foreach my $i (sort {$a <=> $b} keys %introns)
	{
	    if (($read1_start > ($i+4)) and ($read1_start < ($introns{$i}-4)))
	    {
		$s1_tag = "intron";
		$s1_index = $i;
	    }
	    if (($read1_end > ($i+4)) and ($read1_end < ($introns{$i}-4)))
	    {
		$e1_tag = "intron";
		$e1_index = $i;
	    }
	    if (($read2_start > ($i+4)) and ($read2_start < ($introns{$i}-4)))
	    {
		$s2_tag = "intron";
		$s2_index = $i;
	    }
	    if (($read2_end > ($i+4)) and ($read2_end < ($introns{$i}-4)))
	    {
		$e2_tag = "intron";
		$e2_index = $i;
	    }
	}
	
	foreach my $e (sort {$a <=> $b} keys %exons)
	{
	    if (($read1_start >= $e) and ($read1_start < $exons{$e}))
	    {
		$s1_tag = "exon";
		$s1_index = $e;
	    }
	    if (($read1_end >= $e) and ($read1_end < $exons{$e}))
	    {
		$e1_tag = "exon";
		$e1_index = $e;
	    }
	    if (($read2_start >= $e) and ($read2_start < $exons{$e}))
	    {
		$s2_tag = "exon";
		$s2_index = $e;
	    }
	    if (($read2_end >= $e) and ($read2_end < $exons{$e}))
	    {
		$e2_tag = "exon";
		$e2_index = $e;
	    }
	}
	
	my $read1 = read_class($s1_tag, $e1_tag, $s1_index, $e1_index);
        my $read2 = read_class($s2_tag, $e2_tag, $s2_index, $e2_index);
	
	if ($read2 eq "ex-ex")
	{
	    if (abs($exon_index{$s2_index} - $exon_index{$e2_index}) == 1)
	    {
		my $intron_number = min($exon_index{$s2_index}, $exon_index{$e2_index});
		if (($read1 eq "intron") or ($read1 eq "int-int") or ($read1 eq "int-ex") or ($read1 eq "ex-int"))
		{
		    if (abs($read1_start-$read1_end) < 110)
		    {
			my $s1_index_toGo = 0;
			my $e1_index_toGo = 0;
			if ($exon_index{$s1_index}) { $s1_index_toGo = $exon_index{$s1_index}; }
			elsif ($intron_index{$s1_index}) { $s1_index_toGo = $intron_index{$s1_index}; }
			if ($exon_index{$e1_index}) { $e1_index_toGo = $exon_index{$e1_index}; }
			elsif ($intron_index{$e1_index}) { $e1_index_toGo = $intron_index{$e1_index}; }
			my $max_ind = max($s1_index_toGo, $e1_index_toGo);
			my $min_ind = min($s1_index_toGo, $e1_index_toGo);
			if ((($intron_number - $max_ind) <= 1) and (($intron_number - $min_ind) == 1))
			{
			    print BEFORE_A "$data{$p}[0]\n$data{$p}[1]\n";
			    $before_a{$intron_number} += 1;
			}
			elsif ((($intron_number - $max_ind) >= 1) and (($intron_number - $min_ind) >= 2))
			{
			    print BEFORE_D "$data{$p}[0]\n$data{$p}[1]\n";
			    $before_d{$intron_number} += 1;
			}
			elsif ((($max_ind - $intron_number) <= 2) and (($min_ind - $intron_number) == 1))
			{
			    print AFTER_A "$data{$p}[0]\n$data{$p}[1]\n";
			    $after_a{$intron_number} += 1;
			}
			elsif ((($max_ind - $intron_number) >= 2) and ($min_ind - $intron_number) >= 2)
			{
			    print AFTER_D "$data{$p}[0]\n$data{$p}[1]\n";
			    $after_d{$intron_number} += 1;
			}
#			else { print "QUESTION: $data{$p}[0]\n$data{$p}[1]\n"; } # Overlappings within the exon
		    }
		}
	    }
	}
	if ($read1 eq "ex-ex")
	{
	    if (abs($exon_index{$s1_index} - $exon_index{$e1_index}) == 1)
	    {
		my $intron_number = min($exon_index{$s1_index}, $exon_index{$e1_index});
		if (($read2 eq "intron") or ($read2 eq "int-int") or ($read2 eq "int-ex") or ($read2 eq "ex-int"))
		{
		    if (abs($read2_start-$read2_end) < 110)
		    {
			my $s2_index_toGo = 0;
			my $e2_index_toGo = 0;
			if ($exon_index{$s2_index}) { $s2_index_toGo = $exon_index{$s2_index}; }
			elsif ($intron_index{$s2_index}) { $s2_index_toGo = $intron_index{$s2_index}; }
			if ($exon_index{$e2_index}) { $e2_index_toGo = $exon_index{$e2_index}; }
			elsif ($intron_index{$e2_index}) { $e2_index_toGo = $intron_index{$e2_index}; }
			my $max_ind = max($s2_index_toGo, $e2_index_toGo);
			my $min_ind = min($s2_index_toGo, $e2_index_toGo);
			if (($intron_number - $max_ind <= 1) and ($intron_number - $min_ind == 1))
			{
			    print BEFORE_A "$data{$p}[0]\n$data{$p}[1]\n";
			    $before_a{$intron_number} += 1;
			}
			elsif (($intron_number - $max_ind >= 1) and ($intron_number - $min_ind >= 2))
			{
			    print BEFORE_D "$data{$p}[0]\n$data{$p}[1]\n";
			    $before_d{$intron_number} += 1;
			}
			elsif ((($max_ind - $intron_number) <= 2) and (($min_ind - $intron_number) == 1))
			{
			    print AFTER_A "$data{$p}[0]\n$data{$p}[1]\n";
			    $after_a{$intron_number} += 1;
			}
			elsif ((($max_ind - $intron_number) >= 2) and ($min_ind - $intron_number) >= 2)
			{
			    print AFTER_D "$data{$p}[0]\n$data{$p}[1]\n";
			    $after_d{$intron_number} += 1;
			}
#			else { print "QUESTION: $data{$p}[0]\n$data{$p}[1]\n"; } # Overlappings within the exon
		    }
		}
	    }
	}
    }
}
close (AFTER_A);
close (AFTER_D);
close (BEFORE_A);
close (BEFORE_D);

open (RATIOS, ">$ARGV[1].ratios.txt");
foreach my $i (1..$gene_end)
{
    print RATIOS "INTRON=$i\t";
    if ($before_d{$i}) { print RATIOS "BEFORE_DISTANT=$before_d{$i}\t"; }
    elsif (!$before_d{$i}) { print RATIOS "BEFORE_DISTANT=0\t"; }
    if ($before_a{$i}) { print RATIOS "BEFORE_ADJACENT=$before_a{$i}\t"; }
    elsif (!$before_a{$i}) { print RATIOS "BEFORE_ADJACENT=0\t"; }
    if ($after_d{$i}) { print RATIOS "AFTER_DISTANT=$after_d{$i}\t"; }
    elsif (!$after_d{$i}) { print RATIOS "AFTER_DISTANT=0\t"; }
    if ($after_a{$i}) { print RATIOS "AFTER_ADJACENT=$after_a{$i}\t"; }
    elsif (!$after_a{$i}) { print RATIOS "AFTER_ADJACENT=0\t"; }
#RATIOS
    if (($before_a{$i}) and ($after_a{$i})) { print RATIOS "RATIO_ADJ_ONLY=", $before_a{$i}/($before_a{$i}+$after_a{$i}), "\t"; }
    elsif (($before_a{$i}) and (!$after_a{$i})) { print RATIOS "RATIO_ADJ_ONLY=1\t"; }
    elsif (!$before_a{$i}) { print RATIOS "RATIO_ADJ_ONLY=NA\t"; }
    if (($before_d{$i}) and ($after_d{$i})) { print RATIOS "RATIO_DIST_ONLY=", $before_d{$i}/($before_d{$i}+$after_d{$i}), "\t"; }
    elsif (($before_d{$i}) and (!$after_d{$i})) { print RATIOS "RATIO_DIST_ONLY=1\t"; }
    elsif (!$before_d{$i}) { print RATIOS "RATIO_DIST_ONLY=NA\t"; }
    print RATIOS "\n";
}
close (RATIOS);

sub read_class
{
    my $start_tag = shift;
    my $end_tag = shift;
    my $start_index = shift;
    my $end_index = shift;
    
#    print "START_TAG=$start_tag\tEND_TAG=$end_tag\tSTART_INDEX=$start_index\tEND_INDEX=$end_index\t";
    
    if (($start_tag eq "intron") and ($end_tag eq "intron"))
    {
	if ($start_index == $end_index) { return "intron"; }
	else { return "int-int"; }
    }
    elsif (($start_tag eq "intron") and ($end_tag eq "exon"))
    {
        return "int-ex";
    }
    elsif (($start_tag eq "exon") and ($end_tag eq "intron"))
    {
        return "ex-int";
    }
    elsif (($start_tag eq "exon") and ($end_tag eq "exon"))
    {
	if ($start_index == $end_index) { return "exon"; }
        else { return "ex-ex"; }
    }
    else { return "no"; }
}

sub min
{
    my $first_val = shift;
    my $second_val = shift;
    if ($first_val < $second_val) { return $first_val; }
    elsif ($first_val > $second_val) { return $second_val; }
    else { return $second_val; }
}

sub max
{
    my $first_val = shift;
    my $second_val = shift;
    if ($first_val < $second_val) { return $second_val; }
    elsif ($first_val > $second_val) { return $first_val; }
    else { return $second_val; }
}
