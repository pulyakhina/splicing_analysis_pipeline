#!/usr/bin/perl

use warnings;
use strict;

if (@ARGV < 3) { print "USAGE: $0  <SAM file>  <bed_track> <output filename> <cutoff for number of non-overlaping bases (optional, per end separately, default is 2)>\n\n"; exit; }
my $cutoff_alarm = 2;
if ($ARGV[3]) { $cutoff_alarm = $ARGV[3]; }

my $chr = "";
my %include = ();

open (INCLUDE, $ARGV[1]);
while (<INCLUDE>)
{
    chomp;
    if ($_ =~ /chr(.*)\t(\d+)\t(\d+$)/)
    {
	$chr = $1;
	my $start = $2;
	my $end = $3;
	foreach my $i ($start .. $end)
	{
	    $include{$i} = 1;
	}
    }
}
close (INCLUDE);

my %pair1 = ();
my %pair2 = ();

open (SAM, $ARGV[0]);
while (<SAM>)
{
    chomp;
    if ($_ =~ /^@/) { next; }
    else
    {
        my @temp = split '\t', $_;
        my $coord1 = $temp[3]; # start
	$temp[5] =~ s/\d+S//g;
	$temp[5] =~ s/\d+H//g;

	my @temp_ar1 = split(/(?<=[A-Z])/, $temp[5]); # splits the string on letters, but keeps the letters together with the preceeding element.
	my $alarm = 0; #to keep track of positions to be excluded

#	print "$temp[0]\tCOORD=$coord1\tCIGAR=$temp[5]\tTEMP_ARR=@temp_ar1\t";
	foreach my $i (0..$#temp_ar1)
	{
	    if ($temp_ar1[$i] =~ /(\d+)M/)
	    {
		my $cutoff = $1;
		foreach my $j ($coord1 .. ($coord1+$cutoff-1))
		{
		    if ($include{$j}) { $coord1 += 1; }
		    else { $alarm += 1; }
		}
	    }
	    elsif (($temp_ar1[$i] =~ /(\d+)I/) or ($temp_ar1[$i] =~ /(\d+)N/))
	    {
		$coord1 += $1;
	    }
	}
#	print "ALARM=$alarm\tCOORD_NOW_IS=$coord1\n";
	if (($alarm+1) <= $cutoff_alarm)
	{
	    if (($temp[1] & 0x0040) > 0) # the read is the first read in a pair
	    {
		$pair1{$temp[0]} = $_;
	    }
	    else # the read is the second read in a pair
	    {
		$pair2{$temp[0]} = $_;
	    }
	}
    }
}
close (SAM);

open (OUT, ">$ARGV[2]");
foreach my $i (keys %pair1)
{
    if ($pair2{$i})
    {
	print OUT "$pair1{$i}\n$pair2{$i}\n";
    }
}
close (OUT);
